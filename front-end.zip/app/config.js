;(function() {

	'use strict';

	angular.module('qd', [
		'ui.router'
	])
	.config(config);

	// safe dependency injection
	// this prevents minification issues
	config.$inject = ['$stateProvider', '$urlRouterProvider'];

	function config($stateProvider, $urlRouterProvider) {

		$urlRouterProvider.otherwise('/user');

		$urlRouterProvider.when('/user', '/user/dashboard');
		$urlRouterProvider.when('/admin', '/admin/dashboard');

		$stateProvider

			.state('user', {
				url: '/user',
				abstract: true,
				template: '<div ui-view></div>'
			}).state('user.dashboard', {
				url: '/dashboard',
				templateUrl: 'views/user/dashboard.html',
				controller: 'UserDashboardController'
			}).state('user.login', {
				url: '/login',
				templateUrl: 'views/user/login.html',
				controller: 'UserLoginController'
			}).state('user.signup', {
				url: '/signup',
				templateUrl: 'views/user/signup.html',
				controller: 'UserSignupController'
			})

			.state('admin', {
				url: '/admin',
				abstract: true,
				template: '<div ui-view></div>'
			}).state('admin.dashboard', {
				url: '/dashboard',
				template: '<h1>Admin Dashboard</h1>',
				controller: 'AdminDashboardController'
			}).state('admin.login', {
				url: '/login',
				template: '<h1>Admin Login</h1>',
				controller: 'AdminLoginController'
			})

			.state('404', {
				url: '/404',
				template: '<h1>404 Not Found</h1>'
			})

			.state('home', {
				url: '/home',
				templateUrl: 'views/partial-home.html'
			})
				.state('home.list', {
					url: '/list',
					templateUrl: 'views/partial-home-list.html',
					controller: 'ListController'
				})

				// nested list with just some random string data
				.state('home.paragraph', {
					url: '/paragraph',
					template: 'I could sure use a drink right now.'
				})

			// ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
			.state('about', {
				url: '/about',
				views: {
					'': {
						templateUrl: 'views/partial-about.html'
					},
					'columnOne@about': {
						template: 'Look I am a column!'
					},
					'columnTwo@about': { 
						templateUrl: 'views/table-data.html',
						controller: 'ScotchController'
					}
				}
			});
	}



	/**
	 * Run block
	 */
	angular.module('qd')
		.run(run);

	run.$inject = ['$rootScope', '$state', 'LocalStorage'];

	function run($rootScope, $state, LocalStorage) {

		// put here everything that you need to run on page load

		if (LocalStorage.get('admin')) {
			$rootScope.admin = LocalStorage.get('admin');
		}

		if (LocalStorage.get('user')) {
			$rootScope.user = LocalStorage.get('user');
		}
		else {
			LocalStorage.set('user', {
				name: "Mr. Green",
				notifications: 5,
				openTickets: 1,
				loggedIn: true
			});
			$rootScope.user = LocalStorage.get('user');
		}

	}

	/**
	 * Place to store API URL or any other constants
	 * Usage:
	 *
	 * Inject CONSTANTS service as a dependency and then use like this:
	 * CONSTANTS.API_URL
	 */
	angular.module('qd')
		.constant('CONSTANTS', {
			'API_URL': 'http://localhost:3256'
		});

  

	/**
	 * You can intercept any request or response inside authInterceptor
	 * or handle what should happend on 40x, 50x errors
	 * 
	 */
	angular.module('qd')
		.factory('authInterceptor', authInterceptor);

	authInterceptor.$inject = ['$rootScope', '$q', 'LocalStorage', '$location'];

	function authInterceptor($rootScope, $q, LocalStorage, $location) {

		return {

			// intercept every request
			request: function(config) {
				config.headers = config.headers || {};
				return config;
			},

			// Catch 404 errors
			responseError: function(response) {
				if (response.status === 404) {
					$location.path('/');
					return $q.reject(response);
				} else {
					return $q.reject(response);
				}
			}
		};
	}
})();
