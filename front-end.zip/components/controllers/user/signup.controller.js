;(function() {
	'use strict';

	angular.module('qd')
		.controller('UserSignupController', UserSignupController);

	UserSignupController.$inject = [];

	function UserSignupController() {
		
	}
})();