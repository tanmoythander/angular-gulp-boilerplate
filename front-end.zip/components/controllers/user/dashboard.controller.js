;(function() {
	'use strict';

	angular.module('qd')
		.controller('UserDashboardController', UserDashboardController);

	UserDashboardController.$inject = ['$scope', '$rootScope', '$state'];

	function UserDashboardController($scope, $rootScope, $state) {

		checkUser();

		// Functions //
		function checkAdmin() {
			if ($rootScope.admin && $rootScope.admin.loggedIn) {
				$rootScope.user = undefined;
				$state.go('admin.dashboard');
				return true;
			}
			else return false;
		}
		function checkUser() {
			if (checkAdmin()) return;
			if (!($rootScope.user && $rootScope.user.loggedIn)) {
				$state.go('user.login');
			}
		}
	}
})();
