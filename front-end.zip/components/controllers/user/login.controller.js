;(function() {
	'use strict';

	angular.module('qd')
		.controller('UserLoginController', UserLoginController);

	UserLoginController.$inject = ['QueryService'];

	function UserLoginController(QueryService) {
		QueryService.make('POST',
			'/auth/login?username=tanmoy%40gmail.com&password=test-test-test',
			{},
			{}
		)
			.then(function(data) {
				console.log(data);
				profile('59333ca793a1272e2c7e032c');
			})
			.catch(function(err) {
				console.log(err);
			});

		function profile(id) {
			QueryService.make('GET',
				'/api/profile/' + id,
				{},
				{}
			)
				.then(function(data) {
					console.log(data);
				})
				.catch(function(err) {
					console.log(err);
				});
		}
	}
})();