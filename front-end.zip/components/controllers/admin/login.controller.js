;(function() {
	'use strict';

	angular.module('qd')
		.controller('AdminLoginController', AdminLoginController);

	AdminLoginController.$inject = [];

	function AdminLoginController() {
		
	}
})();