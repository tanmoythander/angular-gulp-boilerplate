;(function() {
	'use strict';

	angular.module('qd')
		.controller('AdminDashboardController', AdminDashboardController);

	AdminDashboardController.$inject = ['$scope', '$rootScope', '$state'];

	function AdminDashboardController($scope, $rootScope, $state) {

		checkAdmin();

		// Functions //
		function checkAdmin() {
			if (!$rootScope.admin.loggedIn) {
				$state.go('admin.login');
			}
		}
	}
})();
