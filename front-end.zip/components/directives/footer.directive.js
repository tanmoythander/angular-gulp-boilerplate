;(function() {

  'use strict';

  angular.module('qd')
    .directive('qdFooter', qdFooter);

  function qdFooter () {

    // Definition of directive
    var directiveDefinitionObject = {
      restrict: 'E',
      templateUrl: 'components/directives/footer.html'
    };

    return directiveDefinitionObject;
  }

})();