;(function() {

  'use strict';

  angular.module('qd')
    .directive('qdUserHeader', QdUserHeader);

  QdUserHeader.$inject = [];

  function QdUserHeader () {

    // Definition of directive
    var directiveDefinitionObject = {
      scope: {
        user: '=user'
      },
      restrict: 'E',
      templateUrl: 'components/directives/user.header.html'
    };

    return directiveDefinitionObject;
  }

})();